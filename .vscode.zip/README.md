.De Pátria para Pátria - Projeto TripleTen

- Descrição
  Site responsivo sobre diferentes cidades do mundo, desenvolvido como exercício do curso de Web Dev da TripleTen. Mostra fotos e histórias de lugares especiais.

- Tecnologias Usadas

. HTML5
. CSS3 (Flexbox, Media Queries)
. Metodologia BEM

- Autor

[Felipe Guedes] - Estudante de Desenvolvimento Web na TripleTen# Tripleten web_project_homeland
